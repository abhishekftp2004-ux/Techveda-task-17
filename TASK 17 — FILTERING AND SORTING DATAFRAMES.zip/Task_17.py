import pandas as pd

# Load the dataset
df = pd.read_csv("student_performance.csv")

print("=== ORIGINAL DATA ===")
print(df)

# --------------------------------------------------
# PART A: FILTERING
# --------------------------------------------------

# 1. Python marks >= 80
filter_1 = df[df["Python_Marks"] >= 80]
print("\n1. Python marks >= 80")
print(filter_1[["Student_ID", "Name", "Python_Marks"]])

# 2. Attendance >= 85
filter_2 = df[df["Attendance"] >= 85]
print("\n2. Attendance >= 85")
print(filter_2[["Student_ID", "Name", "Attendance"]])

# 3. Average >= 80 AND attendance >= 85
filter_3 = df[
    (df["Average"] >= 80) &
    (df["Attendance"] >= 85)
]
print("\n3. Average >= 80 AND Attendance >= 85")
print(filter_3[["Student_ID", "Name", "Average", "Attendance"]])

# 4. Python >= 90 OR SQL >= 90
filter_4 = df[
    (df["Python_Marks"] >= 90) |
    (df["SQL_Marks"] >= 90)
]
print("\n4. Python >= 90 OR SQL >= 90")
print(filter_4[["Student_ID", "Name", "Python_Marks", "SQL_Marks"]])

# 5. CSE students with SQL >= 80
filter_5 = df[
    (df["Department"] == "CSE") &
    (df["SQL_Marks"] >= 80)
]
print("\n5. CSE AND SQL >= 80")
print(filter_5[["Student_ID", "Name", "Department", "SQL_Marks"]])

# 6. Active students
filter_6 = df[df["Status"] == "Active"]
print("\n6. Active students")
print(filter_6[["Student_ID", "Name", "Status"]])

# --------------------------------------------------
# PART B: SORTING
# --------------------------------------------------

# 7. Average ascending
sort_1 = df.sort_values(by="Average")
print("\n7. Average - Ascending")
print(sort_1[["Student_ID", "Name", "Average"]])

# 8. Average descending
sort_2 = df.sort_values(by="Average", ascending=False)
print("\n8. Average - Descending")
print(sort_2[["Student_ID", "Name", "Average"]])

# 9. Attendance descending
sort_3 = df.sort_values(by="Attendance", ascending=False)
print("\n9. Attendance - Descending")
print(sort_3[["Student_ID", "Name", "Attendance"]])

# 10. Multiple-column sorting
sort_4 = df.sort_values(
    by=["Department", "Average"],
    ascending=[True, False]
)
print("\n10. Department ascending, Average descending")
print(sort_4[["Student_ID", "Name", "Department", "Average"]])

# --------------------------------------------------
# PART C: FILTER + SORT
# --------------------------------------------------

result = (
    df[df["Attendance"] >= 85]
    .sort_values(by="Average", ascending=False)
)

print("\n11. Attendance >= 85, sorted by Average descending")
print(result[["Student_ID", "Name", "Average", "Attendance"]])

# Top 3
top_3 = df.sort_values(by="Average", ascending=False).head(3)
print("\n12. Top 3 students")
print(top_3[["Student_ID", "Name", "Average"]])

# Bottom 3
bottom_3 = df.sort_values(by="Average").head(3)
print("\n13. Bottom 3 students")
print(bottom_3[["Student_ID", "Name", "Average"]])

# --------------------------------------------------
# PART D: SHORT ANALYSIS
# --------------------------------------------------

print("\n=== SHORT ANALYSIS ===")
print("Number of students:", len(df))
print("Overall average:", round(df["Average"].mean(), 2))
print("Highest average:", df["Average"].max())
print("Lowest average:", df["Average"].min())
print("Students with attendance >= 85:",
      (df["Attendance"] >= 85).sum())
